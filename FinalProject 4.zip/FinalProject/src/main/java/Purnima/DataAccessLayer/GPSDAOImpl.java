/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Purnima.DataAccessLayer;

/**
 *
 * @author DELL
 */
public class GPSDAOImpl {
    
}
